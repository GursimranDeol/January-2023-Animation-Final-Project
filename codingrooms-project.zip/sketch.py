'''
Deol, Gursimran, 707807
ICS3U0 Final Project
January 20th, 2023
https://app.codingrooms.com/w/BCFrRCKaLQBk
'''

#Here I draw my four clouds with ellipses, I added no stroke so the ellipses blend in together. 
def cloud1(x):
   
    noStroke()
    fill(255, 255, 255)
    ellipse(x,400+6,40,40)
    ellipse(x-20,400-6,40,40)
    ellipse(x+25,400+10,40,40)
    ellipse(x-25,400,40,40)
    ellipse(x+15,380,40,40)
    ellipse(x+15,400+25,40,40)

def cloud2(x):
    
    noStroke()
    fill(255, 255, 255)
    ellipse(x,75+100,32,32)
    ellipse(x+20,90+100,32,32)
    ellipse(x-20,90+100,32,32)
    ellipse(x,90+100,32,32)

def cloud3(x):

    noStroke()
    fill(255, 255, 255)
    ellipse(x+10,75+5,30,30)
    ellipse(x+30,75-5,30,30)
    ellipse(x+50,75+5,30,30)
    ellipse(x+70,75-5,30,30)

def cloud4(x):
    
    noStroke()
    fill(255, 255, 255)
    ellipse(x+10,288+10,22,22)
    ellipse(x+20,288-4,22,22)
    ellipse(x+30,288+7,22,22)
    ellipse(x+40,288,22,22)

#I import the plane image here and place it at its respective x and y values. I also add the windows and make then flash random colours with the text "party plane".
def drawplane(x, y):
    global plane1, r, g, b, colour
    image(plane1, x, y)
    stroke(0)
    if frameCount % 25 == 0:
       colour = int(random(0, len(r)))
    for j in range(4):
        fill(r[colour], g[colour], b[colour])
        rect(x+130+30*j, y+130, 10, 10)
    noStroke()
    #Setting up the text for the plane
    textSize(10)
    fill(0, 0, 0)
    text("Party Plane", x+73, y+146)

# I import the four geese pictures and make them switch between eachother after 30 frames so it looks like theyre flapping their wings at their own seperate x and y values.
def wings(x, y):
    global imgup, imgdown, bird
    if bird == 0:
        image(imgup,x, y)
        if frameCount % 25 == 0:
            bird = 1
    else:
        image(imgdown,x, y)
        if frameCount% 25 == 0:
            bird = 0

def wings2(x, y):
    global imgup, imgdown, bird
    if bird == 0:
        image(imgup,x, y)
    else:
        image(imgdown,x, y)

#Setting up all the variables I used to draw and animate each individual portion of my entire animation. I also set up the size and background of the animation. Here is where I simply import my images and make my lists.
def setup():
    global x1, x2, x3, x4, x5, y5, x6, y6, x7, y7, bird, imgup, imgdown, plane1, speed7, r, g, b, colour
    size(500,500)
    speed = 1
    speed7 = 2
    x1 = 500
    x2 = 500
    x3 = 500
    x4 = 500
    x5 = 50
    y5 = 50
    x6 = 350
    y6 = 350
    x7 = 70
    y7 = 100 
    bird = 0
    #Importing images
    imgdown = loadImage("Wingsdown.gif")
    imgup = loadImage("Wingsup.gif")
    plane1 = loadImage("plane.gif")
    #Lists for the three rgb numbers so they can switch randomly.
    r = [0,   0,   0,   0, 255, 255, 255, 255]
    g = [0,   0, 255, 255,   0,   0, 255, 255]
    b = [0, 255,   0, 255,   0, 255,   0, 255]
    colour = 0

#I call all my functions (the things I drew) and animated them separately if appliciable. 
def draw():
    global x1, x2, x3, x4, x6, y6, x5, y5, x7, y7, speed7
    background(173, 216, 230)
    #Where the clouds get their animation, I write each clouds animation and then call the function for the cloud.
    speed1 = -4
    x1 = x1 + speed1
    if x1 < -40:
        x1 = 500
    cloud1(x1)
    speed2 = -3
    x2 = x2 + speed2
    if x2 < -32:
        x2 = 500
    cloud2(x2)
    speed3 = -2
    x3 = x3 + speed3
    if x3 < -100:
        x3 = 500
    cloud3(x3)
    speed4 = -6
    x4 = x4 + speed4
    if x4 < -50:
        x4 = 500
    cloud4(x4)
    #Making the plane move up and down with a math function.
    y7 = height/5 + 30*sin(radians(frameCount*4))
    drawplane(x7, y7)
    wings(x5, y5)
    wings2(x6, y6)


